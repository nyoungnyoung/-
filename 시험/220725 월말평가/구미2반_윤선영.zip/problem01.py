# 전체 점수의 합을 계산하는 함수 total
# sum 함수 사용하자

def total(score):
    return sum(score)


# print(total([80, 90, 85, 75]))
