def dec_to_bin(number):
    return
