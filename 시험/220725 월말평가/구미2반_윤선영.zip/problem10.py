def get_final_position(n, mat, moves):
    for i in moves:
        if i == 0:
            if 1 in mat[0]:
                return None
            else:
                mat
        elif i == 1:
            pass
        elif i == 2:
            pass
        elif i == 3:
            pass


# print(get_final_position(3, [[1, 0, 0], [0, 0, 0], [0, 0, 0]], [1, 1, 3]))
